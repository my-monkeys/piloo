#!/usr/bin/env bash
set -e
R=my-monkeys/piloo
M1="M1 — Fondations techniques"

# Helper: create_task <parent_epic_num> <title> <body> <p0|p1|p2> <platform> <domain> [extra-domain]
create_task() {
  local parent=$1; local title=$2; local body=$3; local prio=$4; local plat=$5; local domain=$6; local extra=$7
  local labels="type:task,priority:$prio,platform:$plat,domain:$domain"
  [ -n "$extra" ] && labels="$labels,domain:$extra"
  local full_body="**Parent**: #$parent

$body"
  gh issue create --repo "$R" --title "$title" --body "$full_body" --label "$labels" --milestone "$M1" 2>/dev/null | grep -oE '[0-9]+$' >/dev/null && echo "  + $title"
}

# E1 — Project setup
P=1
create_task $P "Bootstrap Turborepo + pnpm workspace" "Init monorepo structure: apps/{web,mobile}, packages/{db-schema,api-contract}.

**AC**
- pnpm install root OK
- turbo run lint, type-check fonctionnent
- README technique
**Effort** S" p0 shared setup
create_task $P "Configure ESLint + Prettier + TypeScript strict" "Setup linting + formatting partagé.

**AC**
- Config ESLint partagée packages/config-eslint
- Prettier .prettierrc à la racine
- tsconfig strict avec noUncheckedIndexedAccess
**Effort** S" p0 shared setup
create_task $P "Setup commitlint + husky/lefthook" "Conventional Commits enforced.

**AC**
- commit non-conventional rejeté
- Pre-commit: lint + typecheck staged
**Effort** S" p1 shared setup
create_task $P "GitHub Actions CI (lint + typecheck + test)" "Workflow CI sur PR + main.

**AC**
- Lint + typecheck + tests sur 2 jobs parallèles
- Cache pnpm + turbo
- Status check obligatoire pour merge
**Effort** M" p0 shared setup
create_task $P "README technique + CONTRIBUTING + .env.example" "Documentation dev pour onboarding.

**AC**
- README liste commandes courantes
- CONTRIBUTING explique workflow branches + PR
- .env.example documente toutes les vars attendues
**Effort** S" p1 shared setup

# E2 — DB schema
P=2
create_task $P "Setup Drizzle dans packages/db-schema" "Init Drizzle ORM + drizzle-kit + connexion Postgres.

**AC**
- drizzle.config.ts OK
- Migration empty OK
- Postgres local docker-compose up
**Effort** S" p0 backend setup
create_task $P "Tables users + officines + partages" "Modélisation comptes + officines (perso/patient) + relations partage.

**AC**
- Soft delete partout
- Index sur (user_id, officine_id)
- Tests d'invariants (1 propriétaire unique par officine)
**Effort** M" p0 backend officines
create_task $P "Tables boites + medicaments_bdpm" "Modélisation des boîtes scannées + référentiel BDPM read-only.

**AC**
- Unique (officine_id, lot, numero_serie)
- Fallback unique (CIP13, lot) sans serie
- Index CIP13 + date_peremption
**Effort** M" p0 backend inventory
create_task $P "Tables ordonnances + prescriptions + prises_planifiees" "Modélisation des ordonnances et prises générées.

**AC**
- Cascade soft delete prescriptions / prises
- Index (officine_id, date) sur prises
- Statuts enum (prevue / prise / sautee / oubliee)
**Effort** M" p0 backend ordonnance
create_task $P "Tables alertes + pending_operations" "Modélisation alertes + log opérations sync.

**AC**
- pending_operations: client_id, op_type, payload, status, created_at
- alertes: type enum, lu/non lu, target users
- Index sur status (pending vs synced)
**Effort** M" p0 backend sync
create_task $P "Seed data dev + script reset DB" "Données de dev + script de réinitialisation rapide.

**AC**
- pnpm db:seed insère 1 user, 1 officine perso, 5 boîtes
- pnpm db:reset wipe + migrate + seed
**Effort** S" p2 backend setup

# E3 — API foundation
P=3
create_task $P "POC endpoint /health avec validation Zod" "Premier endpoint pour valider la stack API + middleware Zod.

**AC**
- /api/health retourne 200 + JSON validé
- Erreur Zod retourne 400 structurée
**Effort** S" p0 backend setup
create_task $P "Génération OpenAPI depuis schémas Zod" "zod-to-openapi (ou équivalent) génère openapi.json à chaque build.

**AC**
- /openapi.json servi
- 1 endpoint documenté
- CI génère et commit le fichier
**Effort** M" p0 backend setup
create_task $P "[Spike] Trancher Better Auth vs Clerk" "Comparer features (social, 2FA, RGPD, prix, DX) et trancher pour M1.

**AC**
- Doc ADR avec décision et raisons
- POC fonctionnel avec choix retenu
**Effort** M" p0 backend auth
create_task $P "Intégration auth provider choisi" "Sign-up + sign-in fonctionnels avec sessions.

**AC**
- Endpoint /auth/signup + /auth/login + /auth/logout
- Session cookie web + token mobile
- Tests d'intégration
**Effort** L" p0 backend auth
create_task $P "Génération client TS depuis OpenAPI" "Client typé pour apps/web.

**AC**
- pnpm build:client génère packages/api-client/web
- Hooks React Query auto pour endpoints
**Effort** M" p0 shared setup
create_task $P "Génération client Dart depuis OpenAPI" "Client typé pour apps/mobile (openapi-generator ou équivalent).

**AC**
- Génération automatique avec build_runner
- Modèles Dart immutables
**Effort** M" p0 mobile setup
create_task $P "Middleware RBAC + helpers" "Middleware pour vérifier le rôle de l'utilisateur sur l'officine.

**AC**
- Helper requireRole(officineId, [Owner,Editor])
- Tests sur les 3 rôles
**Effort** M" p0 backend partage

# E4 — Mobile foundation
P=4
create_task $P "Init Flutter project + structure" "apps/mobile avec lib/ structuré (features, core, shared).

**AC**
- iOS + Android build OK
- flutter analyze 0 warnings
**Effort** S" p0 mobile setup
create_task $P "Setup go_router + routes typées" "Navigation déclarative + deep linking ready.

**AC**
- Routes vers tous les écrans M1
- Génération de paths typés
**Effort** M" p0 mobile setup
create_task $P "Setup Riverpod (state management)" "Choix Riverpod (alternative possible Bloc, à confirmer).

**AC**
- Provider de session + storage local
- Tests sur un provider
**Effort** M" p0 mobile setup
create_task $P "Setup Drift + SQLite local" "DB locale mobile avec migrations Drift.

**AC**
- Tables miroirs côté mobile (boites, prises)
- Migration v1 OK
**Effort** M" p0 mobile setup
create_task $P "Theming Piloo + tokens Dart" "Implémenter les tokens design dans Flutter.

**AC**
- ThemeData light avec couleurs Piloo
- Typographie Fraunces + Manrope
- Tokens accessibles via Theme.of(context)
**Effort** M" p0 mobile design-system
create_task $P "Phosphor icons + fonts intégrés" "phosphor_flutter + Google Fonts ou assets locaux.

**AC**
- Toutes les icônes utilisées dans le design accessibles
- Fonts pré-chargées (pas de FOUT)
**Effort** S" p1 mobile design-system
create_task $P "Splash screen + app icons iOS/Android" "Assets natifs.

**AC**
- Splash matching design A1
- Icons aux bonnes résolutions iOS + Android
**Effort** S" p1 mobile design-system

# E5 — Design system
P=5
create_task $P "Tokens partagés JSON → Dart + CSS vars" "Source unique de vérité pour les tokens.

**AC**
- packages/design-tokens exporte JSON
- Génération Dart (Theme) + CSS (variables)
- 1 commande pour rebuilder partout
**Effort** M" p1 shared design-system
create_task $P "Mobile widgets: Button (Primary/Outline/Apple/Google)" "4 variants conformes au design.

**AC**
- Loading state, disabled state, sizes
- Golden tests
**Effort** M" p1 mobile design-system
create_task $P "Mobile widgets: Card, Badge, Header, ScreenWrapper" "Composants structurels.

**AC**
- ScreenWrapper avec status bar + content + safe area
- Golden tests
**Effort** M" p1 mobile design-system
create_task $P "Mobile widgets: TabBar5 + ScanFAB" "Navigation principale avec scan débordant (variant B2 validée).

**AC**
- Tab actif avec animation
- ScanFAB cliquable, animation press
**Effort** M" p1 mobile design-system
create_task $P "Mobile widgets: Input, Checkbox, Radio, Switch" "Inputs basiques.

**AC**
- Validation visuelle (erreur, focus)
- Accessibles (Semantics)
**Effort** M" p1 mobile design-system
create_task $P "Web: shadcn init + customisation tokens Piloo" "Base shadcn/ui adaptée à la marque.

**AC**
- Components.json setup
- Theme custom CSS vars Piloo
**Effort** M" p2 web design-system
create_task $P "Storybook web + déploiement preview" "Doc visuelle des composants web.

**AC**
- Storybook lance en dev
- Preview déployée sur Vercel pour chaque PR
**Effort** M" p2 web design-system

# E6 — Auth flows
P=6
create_task $P "A1 Splash + redirection auth" "Mobile + web. Décide selon session: onboarding / login / aujourd'hui.

**AC**
- < 1s entre splash et destination
- Aucun flicker
**Effort** S" p0 mobile auth
create_task $P "A2 Choix type compte (UI + API)" "Particulier ou Pro. Influence flow downstream.

**AC**
- Sauvegarde côté serveur
- Modifiable depuis Plus plus tard
**Effort** S" p0 shared auth
create_task $P "A4 Inscription email + password" "Form complet avec validation côté client + serveur.

**AC**
- Mot de passe ≥ 8 caractères
- CGU acceptées (checkbox)
- Erreurs serveur affichées clairement
**Effort** M" p0 shared auth
create_task $P "A3 Connexion email + password" "Login standard.

**AC**
- Erreur générique (pas d'enum d'emails)
- Brute-force protection (rate limit)
**Effort** M" p0 shared auth
create_task $P "A5 Vérification email (lien magique 1h)" "Token signé envoyé par email.

**AC**
- Lien expire après 1h
- Page de confirmation web
- App mobile détecte deep link
**Effort** M" p0 shared auth
create_task $P "A6 Mot de passe oublié + reset" "Lien de reset envoyé par email.

**AC**
- Lien 1h
- Nouveau mdp invalide les sessions actives
**Effort** M" p1 shared auth
create_task $P "Apple Sign-In iOS (App Store guideline)" "Sign in with Apple natif. Obligatoire iOS si Google présent.

**AC**
- Bouton conforme HIG Apple
- Gestion email private relay
- Token validé côté serveur
**Effort** L" p0 mobile auth
create_task $P "Google Sign-In iOS + Android + Web" "OAuth Google.

**AC**
- 3 plateformes
- Token validé côté serveur
**Effort** L" p0 shared auth

# E7 — Onboarding
P=7
create_task $P "O1 Welcome slides (carousel 3 slides)" "Skippable, 3 slides illustrant scan/timeline/partage.

**AC**
- Swipeable + dots de pagination
- Skip + Suivant
- Tracking 'first launch done' local
**Effort** M" p1 mobile onboarding
create_task $P "O2 Mentions légales + tracking serveur consentement" "Acceptation explicite CGU + RGPD + disclaimer MDR.

**AC**
- Checkboxes obligatoires
- Server stocke consent_version + timestamp
**Effort** M" p1 shared onboarding legal
create_task $P "O3 Permissions caméra + notifs" "Demande native avec rationale.

**AC**
- Caméra: hard-required, message si refus
- Notifs: optionnel, peut être skip
- Lien vers paramètres OS si refus permanent
**Effort** S" p1 mobile onboarding
create_task $P "Auto-création officine perso au signup particulier" "1 officine 'Mon officine' créée automatiquement.

**AC**
- API signup → création officine immédiate
- Renommable depuis paramètres
**Effort** S" p0 backend officines

# E8 — Officines
P=8
create_task $P "API CRUD officines" "Endpoints /officines POST PUT DELETE GET.

**AC**
- Soft delete
- Validation ownership
**Effort** M" p0 backend officines
create_task $P "UI mobile: création / renommage / archivage officine" "Écrans dans Plus → Mes officines.

**AC**
- Sheet création / édition
- Confirmation archivage
**Effort** M" p0 mobile officines
create_task $P "UI mobile: switcher rapide + S1 Mes officines" "Switcher dans header + écran liste.

**AC**
- Bascule instantanée (state global)
- Indicateur officine active
**Effort** M" p0 mobile officines
create_task $P "UI web: équivalent gestion officines" "Pages web parité mobile.

**AC**
- Sidebar avec switcher
- Page Settings → Officines
**Effort** M" p2 web officines

# E9 — BDPM
P=9
create_task $P "Cron download TSV BDPM (data.gouv 2x/jour)" "Job programmé qui télécharge les fichiers TSV.

**AC**
- Idempotent (skip si version inchangée)
- Logs structurés
- Alerte si échec 3 fois consécutives
**Effort** M" p0 backend bdpm
create_task $P "Parser TSV + insert table medicaments_bdpm" "Transformation + UPSERT.

**AC**
- Tous les champs documentés extraits
- Test sur dataset partiel
- < 5 min pour full reload
**Effort** M" p0 backend bdpm
create_task $P "Endpoint /bdpm/version + diff" "Permet au mobile de savoir quoi télécharger.

**AC**
- /bdpm/version retourne la version active
- /bdpm/diff?from=YYYY-MM retourne les changements
**Effort** M" p0 backend bdpm
create_task $P "Génération SQLite mobile optimisée" "Build d'un fichier .db distribuable.

**AC**
- Index sur CIP13 + nom_substance
- < 50 MB compressé
- Stocké sur CDN
**Effort** M" p0 backend bdpm
create_task $P "Mobile: téléchargement initial BDPM" "Premier lancement ou bouton refresh.

**AC**
- Progress bar
- Reprise si interrompu
- Fallback: 'aucun médicament reconnu' clair
**Effort** M" p0 mobile bdpm
create_task $P "Mobile: diff mensuel BDPM" "Update incrémental.

**AC**
- Vérification version au resume
- Update silencieux si Wi-Fi + chargeur
**Effort** M" p1 mobile bdpm

# E10 — Scan
P=10
create_task $P "Intégration mobile_scanner + permissions" "Lib + flow permission caméra.

**AC**
- iOS + Android OK
- Refus permission → message + lien settings
**Effort** S" p0 mobile scan
create_task $P "Parser GS1 (AI 01, 17, 10, 21)" "Parser robuste avec tests unitaires.

**AC**
- Tous les cas standards
- Tolérance aux espaces FNC1
- Tests > 95% coverage
**Effort** M" p0 mobile scan
create_task $P "UI viewfinder écran 04" "Écran scan implémenté.

**AC**
- Brackets accent terracotta
- Scan line animée
- Bouton Saisie manuelle accessible
**Effort** M" p0 mobile scan
create_task $P "Lookup CIP13 → BDPM SQLite + résolution" "Récupération nom, DCI, dosage, forme.

**AC**
- < 50ms
- Cas CIP13 absent: alerte + saisie manuelle
**Effort** S" p0 mobile scan bdpm
create_task $P "Branchement post-scan (nouvelle vs connue)" "Décide selon (officine_id, lot, serie).

**AC**
- Nouvelle: route → écran 05
- Connue: ouvre bottom sheet écran 07
**Effort** S" p0 mobile scan
create_task $P "Cas erreurs scan + fallback saisie manuelle" "Gestion DataMatrix non-pharma + pas de série.

**AC**
- Messages d'erreur clairs
- Saisie manuelle CIP13 fonctionne
**Effort** M" p1 mobile scan

# E11 — Inventory (M1 partie)
P=11
create_task $P "API CRUD boîtes" "Endpoints /boites GET POST PUT.

**AC**
- Auth + RBAC ownership
- Validation Zod (CIP13 format, dates)
**Effort** M" p0 backend inventory
create_task $P "Écran 03 Officine — liste + filtres + recherche" "Vue principale inventaire.

**AC**
- Filtres: actif/vide/périmé/stock bas
- Recherche fuzzy
- Tri péremption
**Effort** L" p0 mobile inventory
create_task $P "Regroupements: médicament / molécule / plat" "Toggle 3 modes.

**AC**
- Persistence du choix
- Toggle visible accessible
**Effort** M" p1 mobile inventory
create_task $P "Écran 05 Nouvelle boîte (post-scan)" "Form pré-rempli depuis DataMatrix.

**AC**
- Édition péremption + lot
- Choix officine si plusieurs
- Niveau stock initial
**Effort** M" p0 mobile inventory

# E18 — Sync offline (M1 partie)
P=18
create_task $P "Schéma pending_operations Drift" "Table locale mobile pour les opérations en attente.

**AC**
- Champs: client_id, op_type, payload, status, created_at, retry_count
- Index sur status
**Effort** S" p0 mobile sync
create_task $P "Worker Dart connectivity_plus" "Worker qui envoie les ops quand la connexion revient.

**AC**
- Détecte online/offline
- Lance sync push automatique
**Effort** M" p0 mobile sync
create_task $P "Endpoint /sync/push (batch 100 max)" "API qui ingère les opérations en lot.

**AC**
- Idempotence via client_id
- Retour des ACK individuels
**Effort** L" p0 backend sync
create_task $P "Endpoint /sync/pull?since=" "API qui retourne les changements depuis un timestamp.

**AC**
- Pagination si volumineux
- Soft delete inclus
**Effort** M" p0 backend sync
create_task $P "Logique last-write-wins + soft delete" "Résolution conflits côté serveur.

**AC**
- Tests sur cas de conflit (2 devices)
- Pas de DELETE physique
**Effort** M" p0 backend sync
create_task $P "Optimistic UI + badge 'sync en attente'" "UX feedback immédiat + indicateur.

**AC**
- Action visible instantanée
- Badge disparaît quand pending = 0
**Effort** M" p1 mobile sync

# E21 — Privacy & RGPD (M1 partie)
P=21
create_task $P "Pages publiques CGU + politique confidentialité (web)" "Pages statiques /cgu et /privacy.

**AC**
- Versionnées (date dernière maj)
- Lisibles + responsive
**Effort** M" p1 web legal
create_task $P "Anonymisation logs (audit + helpers)" "Aucun nom de médicament, CIP, ou patient en clair dans les logs.

**AC**
- Wrapper logger qui sanitize
- Audit grep des logs en CI (échec si motif sensible)
**Effort** M" p1 backend legal observability

echo
echo "Tasks M1 créées"
