#!/usr/bin/env bash
set -e
R=my-monkeys/piloo
M2="M2 — Features cœur particulier"

create_task() {
  local parent=$1; local title=$2; local body=$3; local prio=$4; local plat=$5; local domain=$6; local extra=$7
  local labels="type:task,priority:$prio,platform:$plat,domain:$domain"
  [ -n "$extra" ] && labels="$labels,domain:$extra"
  local full_body="**Parent**: #$parent

$body"
  gh issue create --repo "$R" --title "$title" --body "$full_body" --label "$labels" --milestone "$M2" 2>/dev/null | grep -oE '[0-9]+$' >/dev/null && echo "  + $title"
}

# E11 — Inventory (M2 partie)
P=11
create_task $P "Écran 08 Détail boîte (lot, péremption, stock, historique)" "Vue détaillée + actions.

**AC**
- Historique des actions (modifier stock / déplacer / etc)
- Bouton modifier ouvre le form
- Action 'voir fiche médicament'
**Effort** M" p1 mobile inventory
create_task $P "Écran 06 Fiche info médicament" "Infos BDPM + résumé IA + lien notice.

**AC**
- DCI cliquable (filtre liste)
- Disclaimer 'à titre indicatif'
- Lien vers PDF notice BDPM
**Effort** M" p1 mobile inventory ai
create_task $P "Action 'voir tous médocs avec ce DCI'" "Navigation depuis fiche info.

**AC**
- Liste filtrée par molécule
- Compteur résultats
**Effort** S" p2 mobile inventory

# E12 — Popup actions
P=12
create_task $P "Bottom sheet UI écran 07 (popup actions rapides)" "Sheet animé avec 5 actions.

**AC**
- Header med info + 5 actions
- Background dim
- Drag-to-dismiss
**Effort** M" p1 mobile inventory
create_task $P "Action ajuster stock — chips rapides" "Plein / 3-4 / Moitié / 1-4 / Vide.

**AC**
- 1 tap = update + close sheet
- Toast confirmation
**Effort** S" p1 mobile inventory
create_task $P "Action ajuster stock — saisie précise" "Champ numérique avec unité (comprimé/sachet/dose).

**AC**
- Validation 0 ≤ N ≤ initial
- Décimales si liquide
**Effort** S" p1 mobile inventory
create_task $P "Actions marquer vide / périmée + confirmation" "Sortie de stock avec confirmation.

**AC**
- Modal de confirmation
- Action écrite dans pending_operations
**Effort** S" p1 mobile inventory
create_task $P "Action signaler manque (tous rôles)" "Crée une alerte visible par Owner + Editors.

**AC**
- Lecteur peut le déclencher
- Notif aux Owner/Editors actifs
**Effort** M" p1 shared inventory alertes

# E13 — Ordonnances
P=13
create_task $P "API CRUD ordonnances + prescriptions" "Endpoints /ordonnances + nested prescriptions.

**AC**
- Validation Zod posologie structurée
- Cascade soft delete
**Effort** L" p1 backend ordonnance
create_task $P "Logique génération prises_planifiees (durée fixe)" "Génère N prises selon durée + moments.

**AC**
- Tests sur cas matin / matin+midi / horaires précis
- Tient compte de horaires utilisateur
**Effort** L" p1 backend ordonnance
create_task $P "Logique génération glissante 'à vie'" "Cron quotidien qui génère J+30.

**AC**
- Pas de duplication
- Idempotent
**Effort** M" p1 backend ordonnance
create_task $P "Écran 09 Liste ordonnances (filtres)" "Vue liste avec filtres actives/terminées.

**AC**
- Tri date
- Card prescripteur + médocs preview
**Effort** M" p1 mobile ordonnance
create_task $P "Écran 10 Création ordonnance — étape 1 (infos)" "Date + prescripteur.

**AC**
- Date picker
- Champ libre prescripteur (avec autocomplete sur historique perso)
**Effort** M" p1 mobile ordonnance
create_task $P "Écran 10 Création — étape 2 (prescriptions)" "Ajout de N prescriptions.

**AC**
- Scan boîte existante OU recherche BDPM
- Posologie phrase naturelle (P2)
- Moments + avec/sans repas + durée
**Effort** L" p1 mobile ordonnance
create_task $P "Écran 10 Création — étape 3 (récap + valider)" "Récapitulatif + bouton Terminer.

**AC**
- Édition possible (back)
- Création serveur en 1 transaction
**Effort** M" p1 mobile ordonnance
create_task $P "Édition + duplication ordonnance" "Renouvellement facile.

**AC**
- Duplique avec date du jour
- Édition modifie en place (avec confirmation)
**Effort** M" p2 mobile ordonnance

# E14 — Timeline Aujourd'hui
P=14
create_task $P "API endpoint /prises/today + /prises?date=" "Récupération des prises planifiées pour un jour.

**AC**
- Inclut statut + lien prescription
- < 100ms
**Effort** M" p0 backend timeline
create_task $P "Écran 02 Aujourd'hui (sections par moment)" "Vue principale.

**AC**
- 4 sections (Matin/Midi/Soir/Coucher)
- Cards Prise avec status + horaire
**Effort** L" p0 mobile timeline
create_task $P "Day picker (navigation jour ±1)" "Naviguer dans le passé/futur.

**AC**
- Limite passé = inscription
- Limite futur = +30j (ou prescription la plus longue)
**Effort** S" p1 mobile timeline
create_task $P "Modale validation Prise / Sautée / Reporter +30" "Bottom sheet d'action.

**AC**
- Tap sur prise ouvre la sheet
- Action écrit pending_operations
**Effort** M" p0 mobile timeline
create_task $P "Cron statut oubliee auto (+1h post-horaire)" "Job serveur qui flag les prises non validées.

**AC**
- Génère alerte prise_oubliee
- Trigger email/push si activé
**Effort** M" p0 backend timeline alertes
create_task $P "Tap long: éditer horaire ponctuel" "Décale juste pour cette occurrence.

**AC**
- Picker time
- Ne change pas la prescription mère
**Effort** M" p2 mobile timeline

# E15 — FCM
P=15
create_task $P "Setup Firebase Project + FCM iOS + Android" "Provisioning + clé APNs + google-services.json.

**AC**
- Notif test reçue iOS + Android
- Documentation onboarding dev
**Effort** L" p0 mobile notif
create_task $P "Enregistrement device token serveur" "API /devices avec token + plateforme.

**AC**
- Cleanup tokens invalides
- 1 user → N devices
**Effort** S" p0 backend notif
create_task $P "Scheduler rappels prises (5 min avant configurable)" "Job qui envoie les push à l'approche des prises.

**AC**
- Précis à la minute
- Désactivable par utilisateur
**Effort** L" p0 backend notif
create_task $P "Notif actions rapides (Prise/Sauter/+15min)" "Catégories notif iOS + actions Android.

**AC**
- Action écrit le statut sans ouvrir l'app
- Fonctionne en background
**Effort** L" p1 mobile notif
create_task $P "Relance +30min + statut oubliee +1h" "Logic chained.

**AC**
- 2e push si pas validé après 30min
- Statut oubliee à +1h (cf E14)
**Effort** M" p1 shared notif

# E16 — Email/SMS Brevo
P=16
create_task $P "Setup Brevo SMTP + API + DKIM/SPF" "Config domaine envoi email.

**AC**
- DMARC OK
- 1 email test reçu sans warning spam
**Effort** M" p1 backend notif legal
create_task $P "Templates: vérif compte + reset mot de passe + invitation officine + alerte critique" "4 templates HTML responsive.

**AC**
- Multi-langue ready
- Branded Piloo
**Effort** M" p1 backend notif
create_task $P "SMS critiques (rate-limit + désactivable)" "Provider Brevo SMS.

**AC**
- Limite N SMS / user / jour
- Toggle dans paramètres
**Effort** M" p2 backend notif
create_task $P "Préférences notif utilisateur (par canal)" "Push / Email / SMS, par type d'événement.

**AC**
- Écran dans Plus
- Persistence serveur + sync
**Effort** M" p1 shared notif settings

# E17 — Alertes
P=17
create_task $P "API endpoints alertes (list + mark read)" "Endpoints /alertes + /alertes/:id/read.

**AC**
- Pagination
- Filtres par type
**Effort** M" p1 backend alertes
create_task $P "Cron quotidien péremption_30j + 7j" "Job nightly qui flag les boîtes proches péremption.

**AC**
- Idempotence (pas de duplicat)
- Push vers Owner/Editors
**Effort** M" p1 backend alertes
create_task $P "Calcul stock estimé + cron stock_bas" "Algo: stock total / consommation prescrite.

**AC**
- Tests sur cas avec/sans prescriptions
- Alerte si < 7 jours estimés
**Effort** L" p1 backend alertes
create_task $P "Endpoint signaler manque + alerte manque_signale" "Trigger depuis l'app, propage aux Owner/Editors.

**AC**
- Notification push aux concernés
- Visible écran 11
**Effort** S" p1 shared alertes
create_task $P "Écran 11 Alertes (groupé par date + tab actif)" "Vue liste avec sections.

**AC**
- 'Tout marquer lu'
- Tap → écran lié à l'alerte
**Effort** M" p1 mobile alertes

# E20 — Plus / Paramètres
P=20
create_task $P "Écran 12 Plus + sections" "Card profil + grid sections.

**AC**
- Tab actif sur Plus
- Hooks vers chaque sous-écran
**Effort** S" p1 mobile settings
create_task $P "Sous-écran Profil (édition nom/email/photo)" "Édition simple.

**AC**
- Validation côté serveur
- Avatar fallback initials (cf design)
**Effort** M" p1 mobile settings
create_task $P "Préférences notifs (par canal × type)" "UI complète préférences.

**AC**
- Toggle par combinaison
- Sync avec serveur
**Effort** M" p1 mobile settings notif
create_task $P "Horaires par défaut (matin/midi/soir/coucher)" "Permet de personnaliser.

**AC**
- Time pickers
- Régénère les prises planifiées affectées
**Effort** M" p2 shared settings
create_task $P "2FA TOTP setup (compte pro)" "QR code + code de secours.

**AC**
- Activable + désactivable
- Codes de secours générés
**Effort** L" p2 shared auth settings
create_task $P "Export données RGPD (article 20)" "Génération JSON + téléchargement.

**AC**
- Tous les champs perso + données médicales
- Format documenté
**Effort** M" p1 backend settings legal
create_task $P "Suppression compte (délai 7 jours)" "Soft delete + grâce + anonymisation finale.

**AC**
- Email confirmation
- Reactivable pendant 7j
- Anonymisation après délai
**Effort** L" p1 shared settings legal

# E21 — Privacy & RGPD (M2 partie)
P=21
create_task $P "Cookies banner web (RGPD compliant)" "Banner + préférences cookies.

**AC**
- Refus = strict minimum
- Préférences modifiables
**Effort** M" p1 web legal
create_task $P "Audit RGPD interne (checklist CNIL)" "Revue complète.

**AC**
- Document d'audit
- TODO list de remédiation
**Effort** M" p1 shared legal
create_task $P "Procédure droit accès / rectification / effacement" "Workflow + endpoints.

**AC**
- Demande tracée
- SLA 1 mois max
**Effort** M" p1 shared legal
create_task $P "DPA avec sous-traitants (Brevo, FCM, hosting)" "Contrats RGPD signés.

**AC**
- Liste sous-traitants à jour
- DPA dans drive
**Effort** S" p1 shared legal
create_task $P "Roadmap HDS (post-MVP commercial)" "Préparer la migration vers hébergeur HDS-certifié pour go-to-market.

**AC**
- ADR + budget + timeline
**Effort** M" p2 shared legal

# E22 — IA résumés
P=22
create_task $P "Pipeline batch génération résumés (LLM)" "Job qui pour chaque CIP13 appelle LLM + stocke.

**AC**
- Prompt versionné
- Coût par génération mesuré
- Rerun ciblé possible
**Effort** L" p2 backend ai
create_task $P "Validation manuelle + UI admin résumés" "Outil interne pour valider/éditer les résumés sensibles.

**AC**
- Listing + édition
- Marquer 'validé manuellement'
**Effort** M" p2 backend ai
create_task $P "Distribution résumés dans SQLite mobile" "Inclus dans le bundle BDPM mobile.

**AC**
- Champ ai_summary dans la table SQLite
- Update lors du diff mensuel
**Effort** S" p2 mobile ai bdpm

# E23 — Web desktop app
P=23
create_task $P "Landing homepage marketing" "Page d'accueil non-app.

**AC**
- Hero + valeur produit + CTA inscription
- Lighthouse > 90
**Effort** L" p2 web design-system
create_task $P "Auth web (parité mobile, A1-A6)" "Toutes les pages auth web.

**AC**
- Mêmes flows mobile
- Apple + Google + email
**Effort** L" p1 web auth
create_task $P "Dashboard widgets (prochaines prises / alertes / stocks)" "Vue d'accueil après login.

**AC**
- 3 widgets minimum
- Responsive
**Effort** L" p1 web timeline
create_task $P "Officine table desktop (sort + filter + panneau latéral)" "Vue inventaire enrichie.

**AC**
- Tri colonne
- Recherche fuzzy
- Détail dans panneau slide
**Effort** L" p1 web inventory
create_task $P "Timeline week view" "Vue 7 jours.

**AC**
- Grille jours × moments
- Statuts visibles
**Effort** M" p2 web timeline
create_task $P "Pages légales statiques (CGU + privacy + mentions)" "Pages MDX.

**AC**
- Versionnées
- Routes /legal/cgu /legal/privacy
**Effort** S" p1 web legal

# E24 — Tests & QA
P=24
create_task $P "Tests unitaires parser GS1 + matching BDPM" "Coverage > 95% sur ces modules critiques.

**AC**
- Cas standards + edge cases
- CI fail si coverage drop
**Effort** M" p1 mobile tests
create_task $P "Tests unitaires sync (push/pull/conflits)" "Tests serveur + tests mobile.

**AC**
- Cas conflit 2 devices
- Cas opération idempotente
**Effort** M" p0 shared tests
create_task $P "Tests unitaires génération prises (durée + à vie)" "Tests sur l'algo de planning.

**AC**
- Cas ordonnance simple, multiple, à vie
- Edge cases (changement horaires user)
**Effort** M" p1 backend tests
create_task $P "Tests intégration API endpoints critiques" "Tests sur Auth + Officines + Boîtes + Sync.

**AC**
- Tests dans CI
- Mock providers externes
**Effort** L" p1 backend tests
create_task $P "Setup TestFlight + Play Console internal" "Distribution interne.

**AC**
- Build auto sur tag release
- 5+ testeurs invités
**Effort** M" p1 mobile tests devops
create_task $P "Bug bash interne avant release M2" "Session test groupée 1 jour.

**AC**
- Plan de test exécuté
- Bugs P0 fixés avant release
**Effort** M" p1 shared tests

# E25 — Déploiement
P=25
create_task $P "Setup Vercel projet web + back" "Hébergement Next.js.

**AC**
- Preview URL par PR
- Prod sur push main
**Effort** M" p0 web devops
create_task $P "Setup Postgres hosting (Neon recommandé)" "DB managée.

**AC**
- Backups automatiques
- Connection string en secret env
**Effort** S" p0 backend devops
create_task $P "DNS + custom domain (piloo.fr ?)" "Domaine + SSL.

**AC**
- piloo.fr et www.piloo.fr résolvent
- HTTPS forcé
**Effort** S" p1 shared devops
create_task $P "Apple Developer enrollment + certificates iOS" "Compte ADP + certs + provisioning.

**AC**
- Certificat distribution
- Provisioning App Store + Ad Hoc
**Effort** M" p0 mobile devops
create_task $P "Provisioning + signing Android" "Keystore + Play Console.

**AC**
- Keystore sauvegardé secret
- App signing via Play (recommended)
**Effort** S" p0 mobile devops
create_task $P "App Store Connect listing + privacy nutrition" "Métadonnées App Store.

**AC**
- Screenshots aux bonnes tailles
- Privacy nutrition labels honnêtes
**Effort** M" p1 mobile devops legal
create_task $P "Play Console listing + privacy" "Métadonnées Play Store.

**AC**
- Screenshots
- Data safety section complétée
**Effort** M" p1 mobile devops legal
create_task $P "CI/CD: deploy auto sur push main" "GitHub Actions → Vercel + builds mobile.

**AC**
- Tag release → build mobile + upload TestFlight + Play
**Effort** M" p1 shared devops

echo
echo "Tasks M2 créées"
