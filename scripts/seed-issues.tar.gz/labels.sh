R=my-monkeys/piloo

create_label() {
  gh label create "$1" --repo "$R" --color "$2" --description "$3" --force >/dev/null 2>&1 && echo "+ $1"
}

# Type
create_label "type:epic" "8B5CF6" "Parent issue tracking a major area of work"
create_label "type:task" "0E8A16" "Concrete unit of work"
create_label "type:bug" "D73A4A" "Bug to fix"
create_label "type:chore" "C5DEF5" "Maintenance / tooling"
create_label "type:spike" "FBCA04" "Time-boxed exploration"

# Platform
create_label "platform:mobile" "4A6B64" "Flutter app"
create_label "platform:web" "A8472E" "Next.js web (incl. API routes)"
create_label "platform:backend" "6B7280" "Server-side / DB / cron"
create_label "platform:shared" "252A30" "Cross-cutting (db-schema, api-contract, design tokens)"

# Priority
create_label "priority:p0" "B60205" "Blocker for current milestone"
create_label "priority:p1" "D93F0B" "Must-have"
create_label "priority:p2" "FBCA04" "Should-have"
create_label "priority:p3" "C2E0C6" "Nice-to-have"

# Domain
create_label "domain:setup" "C5DEF5" "Monorepo, CI, hosting, DX"
create_label "domain:auth" "5319E7" "Sign-in, sign-up, sessions, 2FA"
create_label "domain:onboarding" "C2E0C6" "Welcome, mentions légales, permissions"
create_label "domain:officines" "BFE5BF" "Officines + switcher"
create_label "domain:scan" "F9D0C4" "Camera + GS1 + DataMatrix"
create_label "domain:inventory" "BFE5BF" "Boîtes, stock, péremption"
create_label "domain:ordonnance" "C5DEF5" "Ordonnances + posologie + prises"
create_label "domain:timeline" "DBE3E0" "Aujourd'hui + statuts prises"
create_label "domain:notif" "FEF2C0" "FCM push + email + SMS"
create_label "domain:alertes" "F9D0C4" "Alertes système"
create_label "domain:partage" "D4C5F9" "Multi-user, roles, invitations"
create_label "domain:sync" "FBCA04" "Offline sync"
create_label "domain:settings" "E99695" "Plus / paramètres"
create_label "domain:bdpm" "C5DEF5" "BDPM ingestion + lookup"
create_label "domain:ai" "DBE3E0" "Résumés IA"
create_label "domain:design-system" "F3D9CD" "DS web + mobile, tokens"
create_label "domain:legal" "FEF2C0" "RGPD, CGU, mentions, HDS prep"
create_label "domain:devops" "6B7280" "Deploy, stores, CI/CD"
create_label "domain:tests" "C2E0C6" "Tests unitaires / intégration / e2e"
create_label "domain:observability" "FEF2C0" "Logs, errors, status"
