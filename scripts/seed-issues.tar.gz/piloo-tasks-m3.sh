#!/usr/bin/env bash
set -e
R=my-monkeys/piloo
M3="M3 — Partages & beta"
M4="M4+ — Pro & v2"

create_task_m() {
  local milestone=$1; local parent=$2; local title=$3; local body=$4; local prio=$5; local plat=$6; local domain=$7; local extra=$8
  local labels="type:task,priority:$prio,platform:$plat,domain:$domain"
  [ -n "$extra" ] && labels="$labels,domain:$extra"
  local full_body="**Parent**: #$parent

$body"
  gh issue create --repo "$R" --title "$title" --body "$full_body" --label "$labels" --milestone "$milestone" 2>/dev/null | grep -oE '[0-9]+$' >/dev/null && echo "  + $title"
}

create_m3() { create_task_m "$M3" "$@"; }
create_m4() { create_task_m "$M4" "$@"; }

# E19 — Partages M3
P=19
create_m3 $P "Schéma RBAC officines (rôles + matrice droits)" "Modèle de partages + matrice consultation/édition/admin.

**AC**
- Enum roles: Owner / Editor / Reader
- Documentation matrice complète
**Effort** S" p1 backend partage
create_m3 $P "Middleware RBAC API (enforcement par rôle)" "Wrappers requireRole(...) sur tous les endpoints touchant officines.

**AC**
- Tests par endpoint × rôle
- Lecteur peut signaler manque mais pas modifier
**Effort** L" p0 backend partage
create_m3 $P "Génération JWT invitation (72h)" "Endpoint /invitations qui génère un lien signé.

**AC**
- Token signé + officine_id + role + exp
- Invalidable côté serveur
**Effort** M" p1 backend partage
create_m3 $P "Acceptation invitation (deep link mobile + page web)" "Flow utilisateur cliquant sur le lien.

**AC**
- Si non-loggé: signup/login puis accept
- Aperçu officine + rôle avant accept (cf S4)
**Effort** L" p1 shared partage
create_m3 $P "Email invitation (template Brevo)" "Email reçu par l'invité.

**AC**
- Lien deep link mobile + fallback web
- Branded
**Effort** S" p1 backend partage notif
create_m3 $P "Écran S1 Mes officines (mobile + web)" "Liste avec rôle + bascule.

**AC**
- Statut 'invitation en attente' visible
- Actif vs autres
**Effort** M" p1 shared partage officines
create_m3 $P "Écran S2 Gestion partages (Owner)" "Voir + révoquer + changer rôle des membres.

**AC**
- Confirmation avant révocation
- Owner ne peut pas se révoquer
**Effort** M" p1 mobile partage
create_m3 $P "Écran S3 Inviter quelqu'un" "Form email + rôle.

**AC**
- Validation email
- Lien copiable + envoyé par email
**Effort** S" p1 mobile partage
create_m3 $P "Écran S4 Accepter invitation" "Aperçu officine + droits + accepter/refuser.

**AC**
- Liste claire des droits selon rôle
- Refus = lien invalidé
**Effort** M" p1 mobile partage
create_m3 $P "Tests RBAC matrice complète" "Pour chaque (rôle × action), tester accordé/refusé.

**AC**
- Test paramétrique
- 100% des combinaisons documentées
**Effort** M" p1 backend partage tests

# E23 — Web (M3 partie)
P=23
create_m3 $P "Vue web partages parité mobile" "Toutes les pages partage côté web.

**AC**
- S1, S2, S3 web
- S4 (acceptation) page publique web
**Effort** L" p2 web partage

# E24 — Tests M3
P=24
create_m3 $P "E2E Playwright (auth + scan simulé + ordonnance)" "Tests bout en bout web.

**AC**
- 3 scénarios couverts
- Lance dans CI
**Effort** L" p2 web tests
create_m3 $P "Beta fermée 5-10 testeurs externes" "Recrutement + collecte feedback.

**AC**
- TestFlight + Play interne ouverts
- Survey feedback
- Bugs trackés ici
**Effort** L" p1 shared tests

# E25 — Déploiement M3
P=25
create_m3 $P "Soumission App Store (review)" "Build prod + review iOS.

**AC**
- Apple Sign-In conforme guideline 4.8
- Privacy nutrition validés
- Approuvé après review
**Effort** L" p1 mobile devops
create_m3 $P "Soumission Play Store (review)" "Build prod + review Android.

**AC**
- Data safety conforme
- Approuvé après review
**Effort** L" p1 mobile devops
create_m3 $P "Status page + monitoring" "Sentry + status page publique.

**AC**
- Sentry capture erreurs prod
- Status page publique status.piloo.fr
**Effort** M" p2 shared devops observability

# M4+ — Hors MVP
P=23
create_m4 $P "Vue pro web (dashboard multi-patients)" "Dashboard pour pros gérant N patients.

**AC**
- Vue agrégée
- Tournée du jour
- Indicateurs observance
**Effort** XL" p2 web partage

P=13
create_m4 $P "OCR ordonnance v2 (photo → JSON pré-rempli)" "Photo + LLM vision → form pré-rempli.

**AC**
- L'utilisateur valide chaque ligne
- Précision > 80%
**Effort** XL" p3 shared ordonnance ai

# Cross-cutting M2 supplémentaires
P=23
create_m3 $P "Pricing page (M3+)" "Si freemium / pro payant.

**AC**
- Plans détaillés
- CTA upgrade
**Effort** M" p3 web design-system

echo
echo "Tasks M3 + M4 créées"
