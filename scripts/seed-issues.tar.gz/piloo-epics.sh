#!/usr/bin/env bash
set -e
R=my-monkeys/piloo
M1="M1 — Fondations techniques"
M2="M2 — Features cœur particulier"
M3="M3 — Partages & beta"
M4="M4+ — Pro & v2"

declare -A EPIC

create_epic() {
  local key=$1; local title=$2; local body=$3; local milestone=$4; shift 4
  local labels=$(IFS=,; echo "$*")
  local n=$(gh issue create --repo "$R" --title "$title" --body "$body" --label "$labels" --milestone "$milestone" 2>/dev/null | grep -oE '[0-9]+$')
  EPIC[$key]=$n
  echo "  $key #$n  $title"
}

echo "Creating epics..."

create_epic E1 "[EPIC] Project setup & monorepo" "## Goal
Bootstrapper le monorepo Turborepo, mettre en place les conventions de DX et l'infra de dev.

## Scope
- Turborepo (apps/web, apps/mobile, packages/db-schema, packages/api-contract)
- ESLint + Prettier + TypeScript strict
- Conventional Commits + commitlint
- GitHub Actions CI (lint + typecheck + tests)
- Pre-commit hooks (husky / lefthook)
- Documentation: README.md technique + CONTRIBUTING.md
- Secrets management (.env.example)

## Acceptance
- \`pnpm install\` à la racine, \`turbo lint\` et \`turbo type-check\` passent
- CI verte sur PR
- Convention de commits forcée

## Effort
M" "$M1" "type:epic" "platform:shared" "priority:p0" "domain:setup"

create_epic E2 "[EPIC] DB schema & migrations" "## Goal
Modéliser la base PostgreSQL (Drizzle), les migrations et les invariants métier.

## Scope
- packages/db-schema avec Drizzle ORM
- Tables: users, officines, partages, boites, medicaments_bdpm, ordonnances, prescriptions, prises_planifiees, alertes, pending_operations
- Soft delete partout (deleted_at)
- Index pertinents (CIP13, officine_id, date)
- Migration tooling (drizzle-kit)
- Seed data dev

## Acceptance
- Schema déployable sur Postgres local
- Migrations versionnées et reproductibles
- Tests basiques sur les invariants (cf data-model.md)

## Effort
L" "$M1" "type:epic" "platform:backend" "priority:p0" "domain:setup"

create_epic E3 "[EPIC] API foundation (Zod + OpenAPI + Auth)" "## Goal
Mettre en place la base des API Routes Next.js avec validation Zod, génération OpenAPI et provider d'authentification.

## Scope
- Wrappers API Routes avec validation Zod
- Génération OpenAPI depuis les schémas Zod
- Génération clients TypeScript & Dart depuis OpenAPI
- Choix + intégration Better Auth ou Clerk (à trancher)
- Gestion sessions (web cookies, mobile token)
- Helpers RBAC

## Acceptance
- POC endpoint /health validé Zod + listé dans OpenAPI
- Sign-up + sign-in fonctionnels via API
- Client TS/Dart généré utilisable dans apps/web et apps/mobile

## Effort
L" "$M1" "type:epic" "platform:backend" "priority:p0" "domain:auth"

create_epic E4 "[EPIC] Mobile app foundation (Flutter)" "## Goal
Bootstrapper l'app Flutter avec routing, state management, theming, Drift, et client API.

## Scope
- Flutter 3.x project init
- Routing: go_router
- State management: Riverpod (à confirmer)
- Drift + SQLite
- Phosphor icons + Fraunces/Manrope fonts
- Theme + design tokens partagés
- Client API généré depuis OpenAPI
- Splash screen natif
- App icons + splash assets

## Acceptance
- App build iOS + Android
- Hot reload OK
- Skeleton 'Hello world' avec routing + theme appliqués

## Effort
L" "$M1" "type:epic" "platform:mobile" "priority:p0" "domain:setup"

create_epic E5 "[EPIC] Design system (tokens + components)" "## Goal
Tokens partagés, composants Flutter et composants Next.js cohérents avec les designs Pencil.

## Scope
- Tokens: couleurs, typo, spacing, radii (JSON + Dart + CSS vars)
- Mobile: widgets de base (Button, Card, Badge, Input, Header, TabBar5, ScanFAB, etc.)
- Web: shadcn-based + customisation tokens Piloo
- Documentation Storybook (web) + golden tests (mobile)

## Acceptance
- Tokens identiques sur les 2 plateformes
- Boutons, inputs, cards rendent comme dans Pencil
- Storybook web déployé en preview

## Effort
L" "$M1" "type:epic" "platform:shared" "priority:p1" "domain:design-system"

create_epic E6 "[EPIC] Auth flows (mobile + web)" "## Goal
Implémenter A1-A6 + Apple Sign-In + Google Sign-In sur mobile et web.

## Scope
- Splash (chargement + redirection)
- Choix type compte (particulier / pro)
- Inscription email + password
- Connexion email + password
- Vérification email (lien magique)
- Mot de passe oublié
- Apple Sign-In (iOS guideline 4.8 obligatoire)
- Google Sign-In
- 2FA TOTP (pro, M2)

## Acceptance
- Flows mobile + web fonctionnels avec validation par email
- Apple Sign-In passe la review App Store
- Tests d'intégration sur les flows critiques

## Effort
L" "$M1" "type:epic" "platform:shared" "priority:p0" "domain:auth"

create_epic E7 "[EPIC] Onboarding" "## Goal
Premier lancement: welcome slides, mentions légales, permissions.

## Scope
- O1 Welcome slides (3 slides carousel)
- O2 Mentions légales (CGU + politique de confidentialité, acceptation explicite)
- O3 Permissions (caméra obligatoire, notifs recommandée)
- Création officine perso auto au 1er login

## Acceptance
- L'utilisateur arrive sur Aujourd'hui après l'onboarding
- Acceptation CGU/RGPD tracée serveur
- Permissions correctement demandées avec rationale

## Effort
M" "$M1" "type:epic" "platform:mobile" "priority:p1" "domain:onboarding"

create_epic E8 "[EPIC] Officines (CRUD + switcher)" "## Goal
Gestion complète des officines (perso + patient) avec switcher.

## Scope
- CRUD officines (créer, renommer, supprimer/archiver)
- Auto-création officine 'perso' à l'inscription particulier
- Champs: nom, type, date naissance, notes
- Switcher dans header + écran 'Mes officines' (S1)
- Multi-officines pour pros

## Acceptance
- Un particulier a 1 officine perso au signup
- Bascule rapide entre officines
- API + UI mobile + UI web

## Effort
M" "$M1" "type:epic" "platform:shared" "priority:p0" "domain:officines"

create_epic E9 "[EPIC] BDPM ingestion (server + mobile sync)" "## Goal
Ingestion automatique de la base BDPM officielle, distribution SQLite mobile.

## Scope
- Cron 2x/jour: download TSV BDPM depuis data.gouv.fr
- Parser + insert table medicaments_bdpm
- Génération SQLite optimisée pour mobile
- Endpoint /bdpm/version (versioning + diff)
- Téléchargement initial mobile au 1er lancement
- Diff mensuel mobile

## Acceptance
- Lookup CIP13 < 50ms côté mobile (offline)
- Mise à jour BDPM 2x/jour visible serveur
- Mobile télécharge le diff sans bloquer l'UI

## Effort
L" "$M1" "type:epic" "platform:shared" "priority:p0" "domain:bdpm"

create_epic E10 "[EPIC] Scan DataMatrix" "## Goal
Scan d'une boîte: caméra → DataMatrix → BDPM lookup → résultat.

## Scope
- Intégration mobile_scanner
- UI viewfinder (écran 04 Scan)
- Parser GS1 (AI 01, 17, 10, 21)
- Résolution CIP13 via SQLite BDPM
- Branchement: nouvelle boîte → écran 05 / boîte connue → popup actions 07
- Cas d'erreur: code non pharma, CIP13 absent, pas de série

## Acceptance
- Temps total scan → UI < 1s sur smartphone moyen
- Tests unitaires sur parser GS1 (cas standards + edge cases)
- Fallback saisie manuelle accessible

## Effort
L" "$M1" "type:epic" "platform:mobile" "priority:p0" "domain:scan"

create_epic E11 "[EPIC] Inventory (boîtes + fiche info)" "## Goal
Liste, regroupement, détail des boîtes + fiche info médicament.

## Scope
- Écran 03 Officine (liste avec filtres + recherche + regroupement)
- Écran 05 Nouvelle boîte (post-scan)
- Écran 08 Détail boîte (lot, péremption, stock, historique, modifier)
- Écran 06 Fiche info médicament (DCI, labo, taux remboursement, résumé IA, notice)
- Tri péremption, statuts (actif/vide/périmé)
- Action 'voir tous mes médicaments avec ce DCI'

## Acceptance
- 3 modes regroupement (médicament / molécule / plat)
- Filtres fonctionnels + recherche fuzzy
- API + UI mobile

## Effort
L" "$M1" "type:epic" "platform:mobile" "priority:p0" "domain:inventory"

create_epic E12 "[EPIC] Popup actions rapides" "## Goal
Bottom sheet sur re-scan d'une boîte connue (écran 07).

## Scope
- 5 actions: ajuster stock / fiche info / marquer vide / marquer périmée / signaler manque
- Niveau stock rapide (chips Plein/3-4/Moitié/1-4/Vide)
- Niveau stock précis (saisie numérique)
- Confirmation pour actions destructives
- Disponible aussi depuis détail boîte

## Acceptance
- Bottom sheet animé natif
- Toutes les actions fonctionnent + écrivent dans pending_operations (sync offline)
- Lecteur peut signaler un manque

## Effort
M" "$M2" "type:epic" "platform:mobile" "priority:p1" "domain:inventory"

create_epic E13 "[EPIC] Ordonnances" "## Goal
Saisie manuelle des ordonnances (3 étapes), génération des prises planifiées.

## Scope
- Liste ordonnances (écran 09) avec filtres actives/terminées
- Création ordonnance (écran 10) - 3 étapes (infos / prescriptions / récap)
- Posologie en phrase naturelle (P2 validé)
- Génération prises_planifiees (durée fixe ou 'à vie' glissant 30j)
- API CRUD ordonnances + prescriptions
- Édition + duplication

## Acceptance
- Création ordonnance → prises apparaissent dans Aujourd'hui
- Sync offline OK
- Tests sur génération de prises (cas durée + à vie)

## Effort
XL" "$M2" "type:epic" "platform:shared" "priority:p1" "domain:ordonnance"

create_epic E14 "[EPIC] Timeline Aujourd'hui" "## Goal
Vue principale: prises du jour groupées par moment.

## Scope
- Écran 02 Aujourd'hui
- Day picker (navigation jour/-1/+1)
- 4 sections: Matin / Midi / Soir / Coucher
- Statuts: prevue / prise / sautee / oubliee
- Modale validation (Prise / Sautée / Reporter +30 min)
- Tap long: éditer horaire ponctuel

## Acceptance
- < 500ms premier affichage offline
- Statut oubliee auto à +1h post-horaire prévu
- Tests sur les transitions d'état

## Effort
L" "$M2" "type:epic" "platform:mobile" "priority:p0" "domain:timeline"

create_epic E15 "[EPIC] Notifications push (FCM)" "## Goal
Notifications natives mobile: rappels prises, alertes.

## Scope
- Setup Firebase Cloud Messaging (iOS + Android)
- Enregistrement device token serveur
- Schedule rappels (5 min avant, configurable)
- Actions rapides notif (Prise / Sauter / Rappel +15 min)
- Relance +30 min, statut oubliee à +1h
- Notif alerte péremption / stock bas

## Acceptance
- Notif fiable iOS + Android
- Action rapide écrit le statut sans ouvrir l'app
- Tests sur le pipeline scheduler

## Effort
L" "$M2" "type:epic" "platform:shared" "priority:p0" "domain:notif"

create_epic E16 "[EPIC] Notifications email & SMS (Brevo)" "## Goal
Emails transactionnels + SMS pour cas critiques.

## Scope
- Intégration Brevo (SMTP + API)
- Templates: vérif compte, mot de passe oublié, invitation officine, alerte critique
- SMS: prise oubliée pers. âgée + stock épuisé urgent
- Limite par utilisateur/jour pour SMS
- Préférences utilisateur (par canal)

## Acceptance
- Tous les emails délivrés (DMARC OK)
- SMS limité (rate limit) et désactivable
- Logs anonymisés (pas de noms médocs en clair)

## Effort
M" "$M2" "type:epic" "platform:backend" "priority:p1" "domain:notif"

create_epic E17 "[EPIC] Alertes système" "## Goal
Détection + affichage des alertes (péremption, stock, prises oubliées, manques).

## Scope
- Cron quotidien: peremption_30j, peremption_7j
- Calcul stock estimé (consommation prescriptions vs stock)
- Alerte stock_bas (< 7 jours)
- Alerte prise_oubliee (générée par scheduler timeline)
- Alerte manque_signale (déclenchée par utilisateur)
- Écran 11 Alertes (groupé par date)
- Notif push pour critiques

## Acceptance
- Alertes calculées correctement sur dataset de test
- Pas de duplicats (idempotence)
- Tests unitaires calcul stock

## Effort
L" "$M2" "type:epic" "platform:shared" "priority:p1" "domain:alertes"

create_epic E18 "[EPIC] Sync offline" "## Goal
Toutes les actions mobile fonctionnent offline + sync transparente.

## Scope
- Table pending_operations côté Drift
- Worker Dart (connectivity_plus)
- Endpoints /sync/push (batch 100 max) et /sync/pull?since=
- Last-write-wins sur timestamp serveur
- Soft delete partout
- Optimistic UI
- Badge 'Synchronisation en attente'
- Retry exponentiel + écran d'échecs

## Acceptance
- Mode avion 100% fonctionnel sur consultation + plupart écritures
- Conflits 2 devices: dernier gagne sans crash
- Tests sur les opérations push/pull

## Effort
XL" "$M1" "type:epic" "platform:shared" "priority:p0" "domain:sync"

create_epic E19 "[EPIC] Partages M3 (rôles + invitations)" "## Goal
Multi-utilisateurs avec rôles + invitations par lien JWT.

## Scope
- Rôles: Propriétaire / Éditeur / Lecteur
- RBAC enforcement (API middleware + UI guards)
- Génération lien invitation JWT 72h
- Email invitation (Brevo)
- Écrans S1 Mes officines / S2 Gestion partages / S3 Inviter / S4 Accepter
- Révocation immédiate (next API call → 403)
- Lecteur peut signaler un manque

## Acceptance
- Tests RBAC: chaque rôle ne peut faire que ce qui est listé dans la matrice
- Lien expiré → erreur claire
- Multi-officine pour pro de santé

## Effort
XL" "$M3" "type:epic" "platform:shared" "priority:p1" "domain:partage"

create_epic E20 "[EPIC] Plus / Paramètres" "## Goal
Écran 12 Plus + sous-écrans des paramètres.

## Scope
- Profil (nom, prénom, email, modifier)
- Préférences notifications (par canal)
- Horaires par défaut (matin/midi/soir/coucher)
- Langue (FR pour MVP, infra i18n prête)
- Thème (light pour MVP, dark en M3+)
- 2FA TOTP (pro)
- Export données RGPD
- Suppression compte (délai 7j)
- Aide / FAQ / mentions légales

## Acceptance
- Toutes les actions fonctionnelles
- Suppression compte: anonymisation après délai
- Export RGPD format JSON utilisable

## Effort
M" "$M2" "type:epic" "platform:mobile" "priority:p1" "domain:settings"

create_epic E21 "[EPIC] Privacy & RGPD compliance" "## Goal
Conformité RGPD + préparation HDS.

## Scope
- Pages publiques CGU + politique de confidentialité (web)
- Cookies banner (web)
- Consentements explicites (RGPD)
- Anonymisation logs (jamais de noms méd, CIP, patients en clair)
- Procédure droit accès / rectification / effacement / portabilité
- Audit interne RGPD
- Roadmap HDS (post-MVP commercial, à anticiper)
- DPA avec sous-traitants (Brevo, FCM, hosting)

## Acceptance
- Pages légales en ligne et à jour
- Audit RGPD passé (checklist CNIL)
- Roadmap HDS validée par juridique

## Effort
L" "$M1" "type:epic" "platform:shared" "priority:p1" "domain:legal"

create_epic E22 "[EPIC] Résumés IA médicaments" "## Goal
Pré-génération de résumés courts par CIP13 pour la fiche info.

## Scope
- Pipeline serveur: pour chaque CIP13, appel LLM (Claude/Gemini/Mistral)
- Prompt structuré (à quoi sert + précautions)
- Validation manuelle batch initial
- Stockage table medicaments_bdpm.ai_summary
- Distribution dans SQLite mobile
- Pas d'appel IA temps réel

## Acceptance
- Résumés disponibles offline mobile
- Avertissement 'à titre indicatif' visible UI
- Coût LLM < seuil défini

## Effort
M" "$M2" "type:epic" "platform:backend" "priority:p2" "domain:ai"

create_epic E23 "[EPIC] Web desktop app" "## Goal
App web complémentaire: landing marketing + dashboard pro/particulier.

## Scope
- Landing marketing (homepage, pricing M3+, blog ?)
- Auth web (mêmes flows que mobile)
- Dashboard widgets (prochaines prises, alertes, stocks faibles)
- Officine table (sort/filter/recherche/panneau latéral)
- Timeline week/month view
- Pages légales statiques
- Vue pro web (M4+)

## Acceptance
- Web responsive
- Parité fonctionnelle 'consultation' avec mobile
- Lighthouse > 90

## Effort
XL" "$M2" "type:epic" "platform:web" "priority:p1" "domain:design-system"

create_epic E24 "[EPIC] Tests & QA" "## Goal
Couverture tests + QA process.

## Scope
- Tests unitaires Dart (sync, parser GS1, matching BDPM, génération prises)
- Tests unitaires TS (Zod schemas, RBAC, calcul stock)
- Tests d'intégration API
- Tests E2E web (Playwright)
- Beta testing TestFlight (iOS) + Play Console internal track (Android)
- Test plan documenté
- Bug bash interne

## Acceptance
- Couverture > 70% sur logique métier
- CI bloque les régressions
- Beta interne 5+ utilisateurs sans crash bloquant

## Effort
L" "$M2" "type:epic" "platform:shared" "priority:p1" "domain:tests"

create_epic E25 "[EPIC] Déploiement & distribution" "## Goal
Mise en ligne et distribution sur stores.

## Scope
- Web: Vercel + custom domain (piloo.fr ?)
- Backend: Vercel serverless ou dedicated
- Postgres hosting (Neon recommended)
- iOS: Apple Developer enrollment, certificates, provisioning, App Store Connect, screenshots, listing
- Android: keystore, Play Console, listing, signing
- Privacy nutrition labels (App Store + Play)
- DNS, SSL, monitoring
- Status page

## Acceptance
- Déploiement automatique sur push main (web + back)
- App publiée TestFlight + internal track
- Soumission App Store + Play passée review (M3)

## Effort
L" "$M2" "type:epic" "platform:shared" "priority:p1" "domain:devops"

# write epic numbers to file for next phase
> /tmp/piloo-epic-ids.env
for k in "${!EPIC[@]}"; do
  echo "$k=${EPIC[$k]}" >> /tmp/piloo-epic-ids.env
done
echo "---"
echo "Epics créés: ${#EPIC[@]}"
cat /tmp/piloo-epic-ids.env | sort
